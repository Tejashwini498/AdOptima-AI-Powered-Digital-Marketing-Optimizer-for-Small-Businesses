import React, { useState } from "react";
import { getAIInsights, getHealthScore, getBudgetRecommendation } from "../utils/api";

const IMPACT_COLOR = { high: "#ef4444", medium: "#f59e0b", low: "#22c55e" };
const IMPACT_BG = { high: "#fef2f2", medium: "#fffbeb", low: "#f0fdf4" };

const MOCK_INSIGHTS = {
  summary: "Your Instagram campaign is a standout performer with 13x ROAS, while your Meta Brand Awareness campaign needs immediate attention — it's spending nearly its full budget for minimal return. Prioritize shifting budget toward your top performers.",
  insights: [
    { title: "Instagram is your star — give it more budget", description: "Your Product Launch Instagram campaign earns $13 for every $1 spent, but it's only using 73% of its budget. This is money left on the table.", impact: "high", action: "Increase Instagram campaign budget by $100 and reduce Meta Brand Awareness by the same amount." },
    { title: "Meta Brand Awareness has poor return", description: "The Brand Awareness campaign spent $298 but only generated $480 in revenue — barely breaking even after ad costs. It's not working.", impact: "high", action: "Pause this campaign or reduce its budget to $100/month while you rethink the ad creative and audience targeting." },
    { title: "Google Ads is healthy — maintain it", description: "Your Summer Sale Google Ads campaign has a solid 5x ROAS and is trending upward. It's performing well and close to budget.", impact: "medium", action: "Keep this campaign running as-is. Consider a 10% budget increase if Instagram scaling goes well." },
    { title: "Your overall CTR can be improved", description: "Meta Brand Awareness has only 1% CTR, meaning 99 out of 100 people who see your ad scroll past it. The ad creative likely needs refreshing.", impact: "medium", action: "A/B test 2 new ad creatives for the Meta campaign — try different images and a stronger call-to-action headline." },
  ],
  top_priority: "Shift $100 budget from Meta Brand Awareness to Instagram Product Launch immediately — this single change could increase your monthly revenue by an estimated $600-800."
};

const MOCK_HEALTH = {
  camp_001: { score: 78, grade: "B", summary: "Solid performer with good ROAS and healthy CTR, slight room to improve conversion rate.", strengths: ["Strong ROAS of 5x", "Good CTR of 3.77%"], weaknesses: ["Nearing budget cap", "Conversion rate could be higher"], recommendation: "Add negative keywords to filter low-intent clicks and improve conversion rate." },
  camp_002: { score: 32, grade: "D", summary: "Poor return on spend. High impressions but very low conversion rate signals audience mismatch.", strengths: ["High reach and impressions"], weaknesses: ["Only 1.6x ROAS — barely profitable", "Low CTR of 1%", "Low conversion rate"], recommendation: "Pause and redesign audience targeting. Current audience is too broad." },
  camp_003: { score: 94, grade: "A", summary: "Exceptional performance. Best campaign in your portfolio with outstanding ROAS and CTR.", strengths: ["Incredible 13x ROAS", "High CTR of 4%", "Under budget — room to scale"], weaknesses: ["Not spending full budget — missing growth opportunity"], recommendation: "Increase budget by $100-150 to scale this winning campaign." },
};

const MOCK_BUDGET = {
  total_budget: 1000,
  allocations: [
    { campaign_id: "camp_001", campaign_name: "Summer Sale - Google Ads", current_budget: 500, recommended_budget: 450, change_percent: -10, reason: "Performing well but slightly over-invested. Slightly reduce to free up for Instagram." },
    { campaign_id: "camp_002", campaign_name: "Brand Awareness - Meta", current_budget: 300, recommended_budget: 100, change_percent: -67, reason: "Very poor 1.6x ROAS. Dramatically reduce spend until creative is refreshed." },
    { campaign_id: "camp_003", campaign_name: "Product Launch - Instagram", current_budget: 200, recommended_budget: 450, change_percent: 125, reason: "Outstanding 13x ROAS with room to scale. This is your best-performing campaign." },
  ],
  expected_roas_improvement: "+35-40%",
  summary: "By reallocating budget from the underperforming Meta campaign to your star Instagram campaign, you can significantly boost overall ROAS without increasing total spend."
};

function Card({ children, style }) {
  return <div style={{ background: "#fff", borderRadius: 12, padding: 24, border: "1px solid #e2e8f0", ...style }}>{children}</div>;
}

function LoadingSpinner() {
  return (
    <div style={{ textAlign: "center", padding: 40 }}>
      <div style={{ fontSize: 32, marginBottom: 12 }}>🤖</div>
      <div style={{ color: "#64748b" }}>Gemini is analyzing your campaigns...</div>
    </div>
  );
}

export default function Insights() {
  const [tab, setTab] = useState("insights");
  const [insights, setInsights] = useState(null);
  const [health, setHealth] = useState({});
  const [budget, setBudget] = useState(null);
  const [loading, setLoading] = useState(false);

  const campaigns = [
    { id: "camp_001", name: "Summer Sale - Google Ads" },
    { id: "camp_002", name: "Brand Awareness - Meta" },
    { id: "camp_003", name: "Product Launch - Instagram" },
  ];

  const fetchInsights = async () => {
    setLoading(true);
    try {
      const r = await getAIInsights();
      setInsights(r.data);
    } catch {
      setInsights(MOCK_INSIGHTS);
    } finally { setLoading(false); }
  };

  const fetchHealth = async (id) => {
    setLoading(true);
    try {
      const r = await getHealthScore(id);
      setHealth(prev => ({ ...prev, [id]: r.data }));
    } catch {
      setHealth(prev => ({ ...prev, [id]: MOCK_HEALTH[id] }));
    } finally { setLoading(false); }
  };

  const fetchBudget = async () => {
    setLoading(true);
    try {
      const r = await getBudgetRecommendation(1000);
      setBudget(r.data);
    } catch {
      setBudget(MOCK_BUDGET);
    } finally { setLoading(false); }
  };

  const tabs = [
    { id: "insights", label: "🧠 AI Insights" },
    { id: "health", label: "🏥 Health Scores" },
    { id: "budget", label: "💰 Budget Optimizer" },
  ];

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 700, color: "#1e293b" }}>AI-Powered Insights</h1>
        <p style={{ color: "#64748b", marginTop: 4 }}>Powered by Gemini 1.5 Pro · Click any button to generate live AI analysis</p>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 8, marginBottom: 24 }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            padding: "10px 20px", borderRadius: 8, border: "none", cursor: "pointer",
            fontWeight: 500, fontSize: 14,
            background: tab === t.id ? "#3b82f6" : "#fff",
            color: tab === t.id ? "#fff" : "#64748b",
            border: `1px solid ${tab === t.id ? "#3b82f6" : "#e2e8f0"}`
          }}>{t.label}</button>
        ))}
      </div>

      {/* AI Insights Tab */}
      {tab === "insights" && (
        <div>
          <button onClick={fetchInsights} style={{
            background: "#3b82f6", color: "#fff", border: "none", borderRadius: 8,
            padding: "12px 24px", fontWeight: 600, cursor: "pointer", marginBottom: 20, fontSize: 15
          }}>✨ Generate AI Insights with Gemini</button>

          {loading && <LoadingSpinner />}
          {!loading && insights && (
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              <Card style={{ background: "#eff6ff", border: "1px solid #bfdbfe" }}>
                <div style={{ fontWeight: 600, color: "#1e40af", marginBottom: 8 }}>📋 Summary</div>
                <div style={{ color: "#1e3a8a", lineHeight: 1.6 }}>{insights.summary}</div>
              </Card>

              <Card style={{ background: "#fefce8", border: "1px solid #fde68a" }}>
                <div style={{ fontWeight: 600, color: "#92400e", marginBottom: 8 }}>🎯 Top Priority Action</div>
                <div style={{ color: "#78350f", lineHeight: 1.6 }}>{insights.top_priority}</div>
              </Card>

              {insights.insights?.map((ins, i) => (
                <Card key={i}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                    <div style={{ fontWeight: 600, color: "#1e293b", fontSize: 15 }}>{ins.title}</div>
                    <span style={{
                      background: IMPACT_BG[ins.impact], color: IMPACT_COLOR[ins.impact],
                      padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, textTransform: "uppercase"
                    }}>{ins.impact} impact</span>
                  </div>
                  <div style={{ color: "#475569", lineHeight: 1.6, marginBottom: 12 }}>{ins.description}</div>
                  <div style={{ background: "#f8fafc", borderRadius: 8, padding: "10px 14px", borderLeft: "3px solid #3b82f6" }}>
                    <span style={{ fontWeight: 600, color: "#3b82f6", fontSize: 13 }}>Action: </span>
                    <span style={{ color: "#475569", fontSize: 13 }}>{ins.action}</span>
                  </div>
                </Card>
              ))}
            </div>
          )}
          {!loading && !insights && (
            <Card style={{ textAlign: "center", padding: 48, color: "#94a3b8" }}>
              <div style={{ fontSize: 48, marginBottom: 12 }}>🤖</div>
              <div style={{ fontSize: 16 }}>Click the button above to get AI-powered insights for your campaigns</div>
            </Card>
          )}
        </div>
      )}

      {/* Health Score Tab */}
      {tab === "health" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {campaigns.map(c => {
            const h = health[c.id];
            const gradeColor = { A: "#22c55e", B: "#84cc16", C: "#f59e0b", D: "#ef4444", F: "#991b1b" };
            return (
              <Card key={c.id}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                  <div style={{ fontWeight: 600, color: "#1e293b" }}>{c.name}</div>
                  <button onClick={() => fetchHealth(c.id)} style={{
                    background: "#f1f5f9", border: "none", borderRadius: 8,
                    padding: "8px 16px", cursor: "pointer", fontWeight: 500, fontSize: 13, color: "#475569"
                  }}>🔍 Analyze with Gemini</button>
                </div>
                {loading && !h && <LoadingSpinner />}
                {h && (
                  <div>
                    <div style={{ display: "flex", gap: 20, marginBottom: 16, alignItems: "center" }}>
                      <div style={{
                        width: 72, height: 72, borderRadius: "50%",
                        background: gradeColor[h.grade] || "#94a3b8",
                        display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                        color: "#fff", fontWeight: 700
                      }}>
                        <div style={{ fontSize: 24 }}>{h.grade}</div>
                        <div style={{ fontSize: 12 }}>{h.score}/100</div>
                      </div>
                      <div style={{ color: "#475569", flex: 1, lineHeight: 1.6 }}>{h.summary}</div>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
                      <div style={{ background: "#f0fdf4", borderRadius: 8, padding: 12 }}>
                        <div style={{ fontWeight: 600, color: "#166534", marginBottom: 6, fontSize: 13 }}>✅ Strengths</div>
                        {h.strengths?.map((s, i) => <div key={i} style={{ color: "#166534", fontSize: 13 }}>• {s}</div>)}
                      </div>
                      <div style={{ background: "#fef2f2", borderRadius: 8, padding: 12 }}>
                        <div style={{ fontWeight: 600, color: "#991b1b", marginBottom: 6, fontSize: 13 }}>⚠️ Weaknesses</div>
                        {h.weaknesses?.map((w, i) => <div key={i} style={{ color: "#991b1b", fontSize: 13 }}>• {w}</div>)}
                      </div>
                    </div>
                    <div style={{ background: "#eff6ff", borderRadius: 8, padding: 12, borderLeft: "3px solid #3b82f6" }}>
                      <span style={{ fontWeight: 600, color: "#1e40af", fontSize: 13 }}>💡 Recommendation: </span>
                      <span style={{ color: "#1e3a8a", fontSize: 13 }}>{h.recommendation}</span>
                    </div>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}

      {/* Budget Optimizer Tab */}
      {tab === "budget" && (
        <div>
          <button onClick={fetchBudget} style={{
            background: "#22c55e", color: "#fff", border: "none", borderRadius: 8,
            padding: "12px 24px", fontWeight: 600, cursor: "pointer", marginBottom: 20, fontSize: 15
          }}>💰 Optimize Budget with Gemini</button>

          {loading && <LoadingSpinner />}
          {!loading && budget && (
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              <Card style={{ background: "#f0fdf4", border: "1px solid #bbf7d0" }}>
                <div style={{ fontWeight: 600, color: "#166534", marginBottom: 8 }}>📈 Expected Improvement: {budget.expected_roas_improvement}</div>
                <div style={{ color: "#166534", lineHeight: 1.6 }}>{budget.summary}</div>
              </Card>
              {budget.allocations?.map((a, i) => (
                <Card key={i}>
                  <div style={{ fontWeight: 600, marginBottom: 8, color: "#1e293b" }}>{a.campaign_name}</div>
                  <div style={{ display: "flex", gap: 24, marginBottom: 10 }}>
                    <div>
                      <div style={{ fontSize: 12, color: "#94a3b8" }}>Current Budget</div>
                      <div style={{ fontSize: 20, fontWeight: 700, color: "#64748b" }}>${a.current_budget}</div>
                    </div>
                    <div style={{ fontSize: 24, color: "#94a3b8", alignSelf: "center" }}>→</div>
                    <div>
                      <div style={{ fontSize: 12, color: "#94a3b8" }}>Recommended</div>
                      <div style={{ fontSize: 20, fontWeight: 700, color: a.change_percent > 0 ? "#22c55e" : "#ef4444" }}>${a.recommended_budget}</div>
                    </div>
                    <div style={{ marginLeft: "auto", alignSelf: "center" }}>
                      <span style={{
                        background: a.change_percent > 0 ? "#f0fdf4" : "#fef2f2",
                        color: a.change_percent > 0 ? "#22c55e" : "#ef4444",
                        padding: "4px 12px", borderRadius: 20, fontWeight: 700, fontSize: 14
                      }}>{a.change_percent > 0 ? "+" : ""}{a.change_percent}%</span>
                    </div>
                  </div>
                  <div style={{ fontSize: 13, color: "#64748b", fontStyle: "italic" }}>{a.reason}</div>
                </Card>
              ))}
            </div>
          )}
          {!loading && !budget && (
            <Card style={{ textAlign: "center", padding: 48, color: "#94a3b8" }}>
              <div style={{ fontSize: 48, marginBottom: 12 }}>💰</div>
              <div style={{ fontSize: 16 }}>Click the button above to get AI-powered budget recommendations</div>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
