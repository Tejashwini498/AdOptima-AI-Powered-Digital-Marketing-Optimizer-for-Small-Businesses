import React, { useState } from "react";
import { getWeeklyReport } from "../utils/api";

const MOCK_REPORT = {
  date_range: "March 10 - March 16, 2026",
  headline: "Strong week led by Instagram 🚀 — but Meta is dragging you down",
  overall_sentiment: "positive",
  wins: [
    "Instagram Product Launch hit 13x ROAS — one of the best-performing campaigns we've seen",
    "Google Ads conversions up 12% week-over-week with stable spend",
    "Total revenue of $4,530 achieved on $867 spend this month"
  ],
  concerns: [
    "Meta Brand Awareness spent $298 but only returned $480 — this needs urgent attention",
    "Overall budget utilization at 87% — Instagram has untapped room to grow"
  ],
  priority_actions: [
    { action: "Shift $100 from Meta Brand Awareness to Instagram campaign", deadline: "This week", expected_impact: "Estimated +$800-1,000 additional monthly revenue" },
    { action: "A/B test 2 new creatives for Meta Brand Awareness campaign", deadline: "By Friday", expected_impact: "Improve CTR from 1% to 2-3% within 2 weeks" },
    { action: "Add 10 negative keywords to Google Ads campaign", deadline: "This week", expected_impact: "Reduce wasted spend by ~$30/month and improve conversion rate" }
  ],
  next_week_focus: "Next week, focus on scaling what's working. Your Instagram campaign is a winner — increase its budget and monitor performance daily. Meanwhile, give Meta Brand Awareness a creative refresh before spending more on it. Set a rule: if ROAS doesn't hit 3x by next Friday, pause it entirely and reinvest the budget into Instagram."
};

const SENTIMENT_CONFIG = {
  positive: { bg: "#f0fdf4", border: "#bbf7d0", color: "#166534", icon: "🟢" },
  neutral: { bg: "#f8fafc", border: "#e2e8f0", color: "#475569", icon: "🟡" },
  negative: { bg: "#fef2f2", border: "#fecaca", color: "#991b1b", icon: "🔴" }
};

export default function Reports() {
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchReport = async () => {
    setLoading(true);
    try {
      const r = await getWeeklyReport();
      setReport(r.data);
    } catch {
      setReport(MOCK_REPORT);
    } finally { setLoading(false); }
  };

  const sc = report ? (SENTIMENT_CONFIG[report.overall_sentiment] || SENTIMENT_CONFIG.neutral) : null;

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 700, color: "#1e293b" }}>Weekly AI Report</h1>
        <p style={{ color: "#64748b", marginTop: 4 }}>Auto-generated performance digest powered by Gemini 1.5 Pro</p>
      </div>

      <button onClick={fetchReport} style={{
        background: "#8b5cf6", color: "#fff", border: "none", borderRadius: 8,
        padding: "12px 24px", fontWeight: 600, cursor: "pointer", marginBottom: 24, fontSize: 15
      }}>📧 Generate Weekly Report with Gemini</button>

      {loading && (
        <div style={{ textAlign: "center", padding: 60, background: "#fff", borderRadius: 12, border: "1px solid #e2e8f0" }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>🤖</div>
          <div style={{ color: "#64748b", fontSize: 16 }}>Gemini is writing your weekly digest...</div>
        </div>
      )}

      {!loading && report && (
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          {/* Header Card */}
          <div style={{ background: sc.bg, border: `1px solid ${sc.border}`, borderRadius: 12, padding: 24 }}>
            <div style={{ fontSize: 12, color: sc.color, fontWeight: 600, marginBottom: 6 }}>
              {sc.icon} WEEK OF {report.date_range?.toUpperCase()}
            </div>
            <div style={{ fontSize: 20, fontWeight: 700, color: "#1e293b", lineHeight: 1.4 }}>
              {report.headline}
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
            {/* Wins */}
            <div style={{ background: "#fff", borderRadius: 12, padding: 20, border: "1px solid #e2e8f0" }}>
              <div style={{ fontWeight: 600, color: "#166534", marginBottom: 14, fontSize: 15 }}>🏆 This Week's Wins</div>
              {report.wins?.map((w, i) => (
                <div key={i} style={{ display: "flex", gap: 10, marginBottom: 10 }}>
                  <span style={{ color: "#22c55e", flexShrink: 0 }}>✓</span>
                  <span style={{ color: "#374151", fontSize: 14, lineHeight: 1.5 }}>{w}</span>
                </div>
              ))}
            </div>

            {/* Concerns */}
            <div style={{ background: "#fff", borderRadius: 12, padding: 20, border: "1px solid #e2e8f0" }}>
              <div style={{ fontWeight: 600, color: "#991b1b", marginBottom: 14, fontSize: 15 }}>⚠️ Areas of Concern</div>
              {report.concerns?.map((c, i) => (
                <div key={i} style={{ display: "flex", gap: 10, marginBottom: 10 }}>
                  <span style={{ color: "#ef4444", flexShrink: 0 }}>!</span>
                  <span style={{ color: "#374151", fontSize: 14, lineHeight: 1.5 }}>{c}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Priority Actions */}
          <div style={{ background: "#fff", borderRadius: 12, padding: 20, border: "1px solid #e2e8f0" }}>
            <div style={{ fontWeight: 600, color: "#1e293b", marginBottom: 16, fontSize: 15 }}>🎯 Priority Actions for Next Week</div>
            {report.priority_actions?.map((a, i) => (
              <div key={i} style={{
                display: "grid", gridTemplateColumns: "32px 1fr auto",
                gap: 12, alignItems: "start", marginBottom: 14,
                padding: "12px 16px", background: "#f8fafc", borderRadius: 8
              }}>
                <div style={{
                  width: 28, height: 28, borderRadius: "50%", background: "#3b82f6",
                  color: "#fff", display: "flex", alignItems: "center", justifyContent: "center",
                  fontWeight: 700, fontSize: 13, flexShrink: 0
                }}>{i + 1}</div>
                <div>
                  <div style={{ fontWeight: 600, color: "#1e293b", fontSize: 14, marginBottom: 4 }}>{a.action}</div>
                  <div style={{ fontSize: 13, color: "#22c55e" }}>📈 {a.expected_impact}</div>
                </div>
                <div style={{
                  background: "#eff6ff", color: "#3b82f6", padding: "4px 10px",
                  borderRadius: 20, fontSize: 12, fontWeight: 500, whiteSpace: "nowrap"
                }}>⏰ {a.deadline}</div>
              </div>
            ))}
          </div>

          {/* Next Week Focus */}
          <div style={{ background: "#faf5ff", border: "1px solid #e9d5ff", borderRadius: 12, padding: 20 }}>
            <div style={{ fontWeight: 600, color: "#7e22ce", marginBottom: 10, fontSize: 15 }}>🔮 Next Week's Focus</div>
            <div style={{ color: "#581c87", lineHeight: 1.7, fontSize: 14 }}>{report.next_week_focus}</div>
          </div>
        </div>
      )}

      {!loading && !report && (
        <div style={{ textAlign: "center", padding: 60, background: "#fff", borderRadius: 12, border: "1px solid #e2e8f0", color: "#94a3b8" }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>📧</div>
          <div style={{ fontSize: 16 }}>Click the button above to generate your AI weekly digest</div>
        </div>
      )}
    </div>
  );
}
