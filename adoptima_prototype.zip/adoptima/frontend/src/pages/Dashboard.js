import React, { useState, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";
import { getCampaigns } from "../utils/api";

const MOCK = {
  campaigns: [
    { id: "camp_001", name: "Summer Sale - Google Ads", platform: "Google Ads", status: "active", budget: 500, spend: 423.5, impressions: 48200, clicks: 1820, conversions: 43, revenue: 2150, ctr: 3.77, cpc: 0.23, roas: 5.08, conversion_rate: 2.36, trend: [{date:"Mar 10",spend:52.1,conversions:5,roas:4.8},{date:"Mar 11",spend:61.3,conversions:7,roas:5.2},{date:"Mar 12",spend:58.9,conversions:6,roas:5.1},{date:"Mar 13",spend:70.2,conversions:9,roas:5.6},{date:"Mar 14",spend:65.0,conversions:8,roas:5.3},{date:"Mar 15",spend:66.0,conversions:8,roas:5.0}] },
    { id: "camp_002", name: "Brand Awareness - Meta", platform: "Meta Ads", status: "active", budget: 300, spend: 298.1, impressions: 92000, clicks: 920, conversions: 12, revenue: 480, ctr: 1.00, cpc: 0.32, roas: 1.61, conversion_rate: 1.30, trend: [{date:"Mar 10",spend:48.2,conversions:2,roas:1.4},{date:"Mar 11",spend:50.1,conversions:2,roas:1.5},{date:"Mar 12",spend:49.5,conversions:2,roas:1.6},{date:"Mar 13",spend:51.0,conversions:2,roas:1.7},{date:"Mar 14",spend:50.0,conversions:2,roas:1.7},{date:"Mar 15",spend:49.3,conversions:2,roas:1.6}] },
    { id: "camp_003", name: "Product Launch - Instagram", platform: "Meta Ads", status: "active", budget: 200, spend: 145.3, impressions: 31500, clicks: 1260, conversions: 38, revenue: 1900, ctr: 4.00, cpc: 0.12, roas: 13.08, conversion_rate: 3.02, trend: [{date:"Mar 10",spend:22.1,conversions:6,roas:12.5},{date:"Mar 11",spend:24.3,conversions:7,roas:13.1},{date:"Mar 12",spend:23.8,conversions:6,roas:12.9},{date:"Mar 13",spend:25.1,conversions:7,roas:13.4},{date:"Mar 14",spend:24.5,conversions:6,roas:12.8},{date:"Mar 15",spend:25.5,conversions:6,roas:12.7}] },
  ],
  summary: { total_campaigns: 3, total_budget: 1000, total_spend: 866.9, total_revenue: 4530, total_conversions: 93, overall_roas: 5.22 }
};

const PLATFORM_COLOR = { "Google Ads": "#4285F4", "Meta Ads": "#1877F2" };
const HEALTH_COLOR = (roas) => roas >= 4 ? "#22c55e" : roas >= 2 ? "#f59e0b" : "#ef4444";
const HEALTH_GRADE = (roas) => roas >= 4 ? "A" : roas >= 2 ? "B" : "D";

function StatCard({ label, value, sub, color }) {
  return (
    <div style={{ background: "#fff", borderRadius: 12, padding: "20px 24px", border: "1px solid #e2e8f0", flex: 1 }}>
      <div style={{ fontSize: 13, color: "#64748b", fontWeight: 500, marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 28, fontWeight: 700, color: color || "#1e293b" }}>{value}</div>
      {sub && <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

export default function Dashboard() {
  const [data, setData] = useState(MOCK);
  const [selected, setSelected] = useState(MOCK.campaigns[0]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    getCampaigns()
      .then(r => { setData(r.data); setSelected(r.data.campaigns[0]); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const s = data.summary;

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 700, color: "#1e293b" }}>Campaign Dashboard</h1>
        <p style={{ color: "#64748b", marginTop: 4 }}>March 2026 · {s.total_campaigns} active campaigns</p>
      </div>

      {/* Summary Stats */}
      <div style={{ display: "flex", gap: 16, marginBottom: 24, flexWrap: "wrap" }}>
        <StatCard label="Total Spend" value={`$${s.total_spend?.toFixed(0)}`} sub={`of $${s.total_budget} budget`} />
        <StatCard label="Total Revenue" value={`$${s.total_revenue?.toLocaleString()}`} sub="All platforms" color="#22c55e" />
        <StatCard label="Overall ROAS" value={`${s.overall_roas}x`} sub="Return on ad spend" color="#3b82f6" />
        <StatCard label="Conversions" value={s.total_conversions} sub="Total this month" />
      </div>

      {/* Campaign Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 24 }}>
        {data.campaigns.map((c) => (
          <div key={c.id} onClick={() => setSelected(c)} style={{
            background: "#fff", borderRadius: 12, padding: 20,
            border: `2px solid ${selected?.id === c.id ? "#3b82f6" : "#e2e8f0"}`,
            cursor: "pointer", transition: "border-color 0.2s"
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14, color: "#1e293b" }}>{c.name}</div>
                <div style={{ fontSize: 12, color: PLATFORM_COLOR[c.platform] || "#64748b", fontWeight: 500, marginTop: 2 }}>{c.platform}</div>
              </div>
              <div style={{
                background: HEALTH_COLOR(c.roas), color: "#fff",
                borderRadius: 8, padding: "4px 10px", fontWeight: 700, fontSize: 14
              }}>{HEALTH_GRADE(c.roas)}</div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              {[["ROAS", `${c.roas}x`], ["CTR", `${c.ctr}%`], ["Spend", `$${c.spend}`], ["Conv.", c.conversions]].map(([k, v]) => (
                <div key={k}>
                  <div style={{ fontSize: 11, color: "#94a3b8" }}>{k}</div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: "#1e293b" }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Chart Section */}
      {selected && (
        <div style={{ background: "#fff", borderRadius: 12, padding: 24, border: "1px solid #e2e8f0" }}>
          <h3 style={{ fontWeight: 600, marginBottom: 20, color: "#1e293b" }}>
            📈 {selected.name} — 6-Day Trend
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
            <div>
              <div style={{ fontSize: 13, color: "#64748b", marginBottom: 8 }}>Daily Spend ($)</div>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={selected.trend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="spend" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div>
              <div style={{ fontSize: 13, color: "#64748b", marginBottom: 8 }}>ROAS Trend</div>
              <ResponsiveContainer width="100%" height={180}>
                <LineChart data={selected.trend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Line type="monotone" dataKey="roas" stroke="#22c55e" strokeWidth={2} dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
