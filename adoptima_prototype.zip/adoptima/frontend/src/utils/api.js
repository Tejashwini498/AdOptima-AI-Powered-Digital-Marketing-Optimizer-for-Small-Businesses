import axios from "axios";

const API = axios.create({
  baseURL: process.env.REACT_APP_API_URL || "http://localhost:8000",
});

export const getCampaigns = () => API.get("/api/campaigns/");
export const getCampaign = (id) => API.get(`/api/campaigns/${id}`);
export const getAIInsights = () => API.get("/api/insights/ai-insights");
export const getHealthScore = (id) => API.get(`/api/insights/health-score/${id}`);
export const getBudgetRecommendation = (budget) =>
  API.post("/api/insights/budget-optimizer", { total_budget: budget });
export const getWeeklyReport = () => API.get("/api/reports/weekly");
