import React, { useState } from "react";
import Dashboard from "./pages/Dashboard";
import Insights from "./pages/Insights";
import Reports from "./pages/Reports";
import "./App.css";

export default function App() {
  const [activePage, setActivePage] = useState("dashboard");

  const navItems = [
    { id: "dashboard", label: "📊 Dashboard" },
    { id: "insights", label: "🤖 AI Insights" },
    { id: "reports", label: "📧 Weekly Report" },
  ];

  return (
    <div style={{ fontFamily: "Inter, sans-serif", minHeight: "100vh", background: "#f8fafc" }}>
      {/* Header */}
      <header style={{
        background: "#fff", borderBottom: "1px solid #e2e8f0",
        padding: "0 32px", display: "flex", alignItems: "center",
        justifyContent: "space-between", height: 64, position: "sticky", top: 0, zIndex: 100
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 24 }}>🚀</span>
          <span style={{ fontWeight: 700, fontSize: 20, color: "#1e293b" }}>AdOptima</span>
          <span style={{
            background: "#eff6ff", color: "#3b82f6", fontSize: 11,
            padding: "2px 8px", borderRadius: 20, fontWeight: 600
          }}>by SolveSphere</span>
        </div>
        <nav style={{ display: "flex", gap: 8 }}>
          {navItems.map((item) => (
            <button key={item.id} onClick={() => setActivePage(item.id)} style={{
              padding: "8px 16px", borderRadius: 8, border: "none", cursor: "pointer",
              fontWeight: 500, fontSize: 14,
              background: activePage === item.id ? "#3b82f6" : "transparent",
              color: activePage === item.id ? "#fff" : "#64748b",
            }}>
              {item.label}
            </button>
          ))}
        </nav>
        <div style={{
          background: "#f1f5f9", borderRadius: 8, padding: "6px 14px",
          fontSize: 13, color: "#475569", fontWeight: 500
        }}>
          🏪 Demo Store
        </div>
      </header>

      {/* Page Content */}
      <main style={{ padding: "32px", maxWidth: 1200, margin: "0 auto" }}>
        {activePage === "dashboard" && <Dashboard />}
        {activePage === "insights" && <Insights />}
        {activePage === "reports" && <Reports />}
      </main>
    </div>
  );
}
