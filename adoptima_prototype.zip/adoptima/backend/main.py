from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
import os

from routers import campaigns, insights, reports, health

load_dotenv()

app = FastAPI(
    title="AdOptima API",
    description="AI-Powered Digital Marketing Optimizer — SolveSphere",
    version="1.0.0",
)

# CORS
allowed_origins = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(campaigns.router, prefix="/api/campaigns", tags=["Campaigns"])
app.include_router(insights.router, prefix="/api/insights", tags=["AI Insights"])
app.include_router(reports.router, prefix="/api/reports", tags=["Reports"])
app.include_router(health.router, prefix="/api/health", tags=["Health"])


@app.get("/")
def root():
    return {"message": "AdOptima API is running", "version": "1.0.0"}
