import google.generativeai as genai
import os
import json
from dotenv import load_dotenv

load_dotenv()

genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
model = genai.GenerativeModel("gemini-1.5-pro")


def generate_campaign_insights(campaigns: list[dict]) -> dict:
    """Use Gemini to generate plain-language insights from campaign data."""

    campaign_summary = json.dumps(campaigns, indent=2)

    prompt = f"""
You are an expert digital marketing analyst helping small business owners.
Analyze the following ad campaign data and provide actionable insights.

Campaign Data:
{campaign_summary}

Respond ONLY with a JSON object in this exact format:
{{
  "summary": "2-3 sentence plain-language overview of overall performance",
  "insights": [
    {{
      "title": "Short insight title",
      "description": "Plain-language explanation (1-2 sentences, no jargon)",
      "impact": "high|medium|low",
      "action": "Specific step the business owner should take"
    }}
  ],
  "top_priority": "The single most important action to take right now"
}}

Rules:
- Write like you're talking to someone with NO marketing background
- Be specific, not generic
- Focus on actionable steps, not just observations
- Maximum 5 insights
"""

    response = model.generate_content(prompt)
    text = response.text.strip()

    # Strip markdown code fences if present
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]
    text = text.strip()

    return json.loads(text)


def generate_health_score(campaign: dict) -> dict:
    """Use Gemini to score a campaign and explain the score."""

    prompt = f"""
You are a digital marketing expert. Score this ad campaign and explain why.

Campaign:
{json.dumps(campaign, indent=2)}

Respond ONLY with a JSON object:
{{
  "score": <integer 0-100>,
  "grade": "A|B|C|D|F",
  "summary": "One sentence explanation of this score",
  "strengths": ["strength 1", "strength 2"],
  "weaknesses": ["weakness 1", "weakness 2"],
  "recommendation": "The #1 thing to fix right now"
}}
"""

    response = model.generate_content(prompt)
    text = response.text.strip()
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]
    text = text.strip()

    return json.loads(text)


def generate_budget_recommendation(campaigns: list[dict], total_budget: float) -> dict:
    """Use Gemini to suggest budget reallocation across campaigns."""

    prompt = f"""
You are a digital marketing budget expert. Recommend how to reallocate a total
monthly budget of ${total_budget:.2f} across these campaigns to maximize ROAS.

Campaigns:
{json.dumps(campaigns, indent=2)}

Respond ONLY with a JSON object:
{{
  "total_budget": {total_budget},
  "allocations": [
    {{
      "campaign_id": "<id>",
      "campaign_name": "<name>",
      "current_budget": <number>,
      "recommended_budget": <number>,
      "change_percent": <number>,
      "reason": "Plain-language reason for this change"
    }}
  ],
  "expected_roas_improvement": "<e.g. +15-20%>",
  "summary": "2 sentence explanation of the strategy"
}}
"""

    response = model.generate_content(prompt)
    text = response.text.strip()
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]
    text = text.strip()

    return json.loads(text)


def generate_weekly_report(campaigns: list[dict], date_range: str) -> dict:
    """Use Gemini to generate a weekly performance digest."""

    prompt = f"""
You are a marketing analyst writing a weekly digest for a small business owner.
Write in simple, encouraging language. Date range: {date_range}

Campaign Data:
{json.dumps(campaigns, indent=2)}

Respond ONLY with a JSON object:
{{
  "date_range": "{date_range}",
  "headline": "Catchy one-line summary of the week",
  "overall_sentiment": "positive|neutral|negative",
  "wins": ["win 1", "win 2", "win 3"],
  "concerns": ["concern 1", "concern 2"],
  "priority_actions": [
    {{
      "action": "Specific action to take",
      "deadline": "e.g. This week / By Friday",
      "expected_impact": "What improvement to expect"
    }}
  ],
  "next_week_focus": "One paragraph about what to focus on next week"
}}
"""

    response = model.generate_content(prompt)
    text = response.text.strip()
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]
    text = text.strip()

    return json.loads(text)
