from fastapi import APIRouter
from services.mock_data import MOCK_CAMPAIGNS, TOTAL_BUDGET, TOTAL_SPEND, TOTAL_REVENUE, TOTAL_CONVERSIONS

router = APIRouter()


@router.get("/")
def get_all_campaigns():
    """Return all campaigns with summary stats."""
    return {
        "campaigns": MOCK_CAMPAIGNS,
        "summary": {
            "total_campaigns": len(MOCK_CAMPAIGNS),
            "total_budget": TOTAL_BUDGET,
            "total_spend": TOTAL_SPEND,
            "total_revenue": TOTAL_REVENUE,
            "total_conversions": TOTAL_CONVERSIONS,
            "overall_roas": round(TOTAL_REVENUE / TOTAL_SPEND, 2) if TOTAL_SPEND > 0 else 0,
        },
    }


@router.get("/{campaign_id}")
def get_campaign(campaign_id: str):
    """Return a single campaign by ID."""
    campaign = next((c for c in MOCK_CAMPAIGNS if c["id"] == campaign_id), None)
    if not campaign:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Campaign not found")
    return campaign
