from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from services.gemini_service import generate_campaign_insights, generate_health_score, generate_budget_recommendation
from services.mock_data import MOCK_CAMPAIGNS, TOTAL_BUDGET

router = APIRouter()


class BudgetRequest(BaseModel):
    total_budget: float = TOTAL_BUDGET


@router.get("/ai-insights")
def get_ai_insights():
    """Generate Gemini-powered insights for all campaigns."""
    try:
        result = generate_campaign_insights(MOCK_CAMPAIGNS)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gemini API error: {str(e)}")


@router.get("/health-score/{campaign_id}")
def get_health_score(campaign_id: str):
    """Get AI-generated health score for a specific campaign."""
    campaign = next((c for c in MOCK_CAMPAIGNS if c["id"] == campaign_id), None)
    if not campaign:
        raise HTTPException(status_code=404, detail="Campaign not found")
    try:
        result = generate_health_score(campaign)
        return {"campaign_id": campaign_id, "campaign_name": campaign["name"], **result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gemini API error: {str(e)}")


@router.post("/budget-optimizer")
def get_budget_recommendation(request: BudgetRequest):
    """Get AI-powered budget reallocation recommendations."""
    try:
        result = generate_budget_recommendation(MOCK_CAMPAIGNS, request.total_budget)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gemini API error: {str(e)}")
