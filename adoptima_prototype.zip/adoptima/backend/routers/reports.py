from fastapi import APIRouter, HTTPException
from services.gemini_service import generate_weekly_report
from services.mock_data import MOCK_CAMPAIGNS

router = APIRouter()


@router.get("/weekly")
def get_weekly_report():
    """Generate AI weekly performance digest."""
    try:
        result = generate_weekly_report(MOCK_CAMPAIGNS, "March 10 - March 16, 2026")
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gemini API error: {str(e)}")
