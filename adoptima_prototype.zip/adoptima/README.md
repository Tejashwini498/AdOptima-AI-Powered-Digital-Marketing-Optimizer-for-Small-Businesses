# AdOptima 🚀
### AI-Powered Digital Marketing Optimizer for Small Businesses
> Built by **SolveSphere** for Google Solution Challenge 2026

AdOptima aggregates your ad campaign data from multiple platforms and uses **Gemini 1.5 Pro** to generate plain-language, actionable recommendations — no marketing expertise needed.

---

## ✨ Features
- 📊 **Unified Dashboard** — Google Ads + Meta campaign metrics in one place
- 🤖 **AI Insights** — Gemini-powered plain-language recommendations
- 🏥 **Campaign Health Score** — Automatic scoring with root-cause analysis
- 💰 **Budget Optimizer** — AI-driven budget reallocation suggestions
- 📧 **Weekly AI Report** — Auto-generated performance digest

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Tailwind CSS, Recharts |
| Backend | Python 3.11, FastAPI |
| AI | Gemini 1.5 Pro API |
| Database | Google BigQuery |
| Auth | Firebase Authentication |
| Hosting | Google Cloud Run + Firebase Hosting |
| CI/CD | GitHub Actions |

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- Python 3.11+
- Google Gemini API key ([Get one here](https://makersuite.google.com/app/apikey))

### 1. Clone the repo
```bash
git clone https://github.com/SolveSphere/adoptima.git
cd adoptima
```

### 2. Backend Setup
```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Create .env file
cp .env.example .env
# Add your GEMINI_API_KEY in .env

uvicorn main:app --reload --port 8000
```

### 3. Frontend Setup
```bash
cd frontend
npm install
cp .env.example .env.local
# Add your API URL in .env.local

npm start
```

### 4. Open in browser
- Frontend: http://localhost:3000
- Backend API docs: http://localhost:8000/docs

---

## 📁 Project Structure
```
adoptima/
├── frontend/               # React app
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Dashboard, Insights, Reports
│   │   └── utils/          # API helpers, mock data
│   └── package.json
├── backend/                # FastAPI app
│   ├── main.py             # App entry point
│   ├── routers/            # API route handlers
│   ├── services/           # Gemini, metrics logic
│   └── requirements.txt
├── docs/                   # Architecture diagrams
└── README.md
```

---

## 🌐 Live Demo
- **MVP**: https://adoptima.web.app
- **Demo Video**: https://youtu.be/[your-video-id]

---

## ☁️ Google Cloud Deployment

```bash
# Deploy backend to Cloud Run
gcloud run deploy adoptima-backend \
  --source ./backend \
  --region us-central1 \
  --allow-unauthenticated

# Deploy frontend to Firebase
cd frontend && npm run build
firebase deploy
```

---

## 📄 License
MIT License — see [LICENSE](LICENSE)
